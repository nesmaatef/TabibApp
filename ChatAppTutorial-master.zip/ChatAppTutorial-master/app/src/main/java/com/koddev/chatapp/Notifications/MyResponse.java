package com.koddev.chatapp.Notifications;

public class MyResponse {

    public int success;
}
